#!/bin/bash

chmod +x ./main.py | python3 ./main.py
